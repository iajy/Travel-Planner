import React from 'react';
import AppBar from './AppBar';

const Switzerland = () => {
    return (
        <div>
            <AppBar/>
            
        </div>
    );
}

export default Switzerland;
