import React from "react";
import AppBar from "./AppBar";

const London = () => {
  return (
    <div className="">
      <AppBar />
    </div>
  );
};

export default London;
