import React from 'react';
import AppBar from "./AppBar"

const India = () => {
    return (
        <div className=''>
            <AppBar/>
            
        </div>
    );
}

export default India;
